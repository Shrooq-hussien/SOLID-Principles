public interface IWork{ void Work(); }
public interface IEat{ void Eat(); }
public class Robot:IWork{ public void Work(){} }