# C# SOLID Violations and Fixes

This repository contains examples of SOLID principle violations and corrected versions.
Each folder includes:
- Bad.cs (violation)
- Good.cs (refactored)
- Program.cs (runnable sample)

