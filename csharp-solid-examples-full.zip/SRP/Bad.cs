public class InvoiceService {
    public void CreateInvoice() {}
    public void SaveToDatabase() {}
    public void SendEmail() {}
}