public class InvoiceCreator { public void CreateInvoice() {} }
public class InvoiceRepository { public void Save() {} }
public class EmailService { public void Send() {} }